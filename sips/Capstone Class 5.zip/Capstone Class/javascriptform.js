function updateCharacterCount(textarea) {
    const maxLength = 500;
    const currentLength = textarea.value.length;
    const remaining = maxLength - currentLength;
    const characterCount = document.getElementById('characterCount');
    
    characterCount.textContent = `${remaining} characters remaining`;
}

function validateForm() {
    const message = document.getElementById('content').value;
    if (message.length > 500) {
        alert('Message should not exceed 500 characters.');
        return false;
    }
    return true;
}
function likePost(postId) {
    var likeCount = document.getElementById("like-count-" + postId);
    likeCount.innerHTML = parseInt(likeCount.innerHTML) + 1;
    console.log("Liked post with ID: " + postId);
    // Implement server-side logic to handle the like
}

function dislikePost(postId) {
    var dislikeCount = document.getElementById("dislike-count-" + postId);
    dislikeCount.innerHTML = parseInt(dislikeCount.innerHTML) + 1;
    console.log("Disliked post with ID: " + postId);
    // Implement server-side logic to handle the dislike
}
